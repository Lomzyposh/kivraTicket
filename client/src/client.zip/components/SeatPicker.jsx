/**
 * SeatPicker.jsx
 * ─────────────────────────────────────────────────────────────────────
 * Renders one of three venue layouts based on event.venueType:
 *   "stadium"  → oval layout (sports, football, athletics)
 *   "concert"  → C-shape / horseshoe layout (arenas, theatres)
 *   "ga"       → General admission ticket-type cards (festivals, clubs)
 *
 * Falls back to "ga" if venueType is missing or unrecognised.
 *
 * Props
 * ─────
 *   event      – full event object from your API
 *   onConfirm  – (selectionPayload) => void
 *                payload shape: { seats: string[], totalPrice: number }
 *                  or for GA:   { tickets: [{typeId, label, qty, price}], totalPrice: number }
 *
 * Availability control
 * ────────────────────
 * event.seatingLayout.availableSeats      → random N seats available
 * event.seatingLayout.availableSeatIds    → exact seat IDs available
 * event.seatingLayout.availableSeatIdsBySection → per-section control
 * ─────────────────────────────────────────────────────────────────────
 */

import React, { useCallback, useMemo, useState } from "react";

// ─── helpers ──────────────────────────────────────────────────────────

function currencySymbol(code = "USD") {
  return { USD: "$", NGN: "₦", GBP: "£", EUR: "€" }[code] ?? "";
}

function rowLetter(i) {
  return String.fromCharCode(65 + i);
}

function seatId(row, col) {
  return `${rowLetter(row)}${col + 1}`;
}

function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function clamp(num, min, max) {
  return Math.max(min, Math.min(max, num));
}

function buildSeatMapFromAvailability(rows, cols, allowedSeatIds = []) {
  const allowed = new Set(allowedSeatIds);
  return Array.from({ length: rows }, (_, r) =>
    Array.from({ length: cols }, (_, c) =>
      allowed.has(seatId(r, c)) ? "available" : "taken",
    ),
  );
}

function buildSectionSeatMaps(sections, seatingLayout = {}) {
  const explicitBySection = seatingLayout?.availableSeatIdsBySection;
  const explicitGlobal = seatingLayout?.availableSeatIds;

  if (explicitBySection && typeof explicitBySection === "object") {
    const result = {};
    sections.forEach((sec) => {
      result[sec.id] = buildSeatMapFromAvailability(
        sec.rows,
        sec.cols,
        explicitBySection[sec.id] ?? [],
      );
    });
    return result;
  }

  if (Array.isArray(explicitGlobal) && explicitGlobal.length > 0) {
    const parsedBySection = {};
    sections.forEach((sec) => {
      parsedBySection[sec.id] = [];
    });

    explicitGlobal.forEach((fullId) => {
      if (typeof fullId !== "string") return;
      const parts = fullId.split("-");
      if (parts.length < 2) return;
      const [sectionPrefix, ...rest] = parts;
      const localSeatId = rest.join("-");
      if (parsedBySection[sectionPrefix]) {
        parsedBySection[sectionPrefix].push(localSeatId);
      }
    });

    const result = {};
    sections.forEach((sec) => {
      result[sec.id] = buildSeatMapFromAvailability(
        sec.rows,
        sec.cols,
        parsedBySection[sec.id] ?? [],
      );
    });
    return result;
  }

  const totalAvailable = clamp(
    Number.isFinite(seatingLayout?.availableSeats)
      ? seatingLayout.availableSeats
      : Number.isFinite(seatingLayout?.availableSeatCount)
        ? seatingLayout.availableSeatCount
        : 10,
    0,
    sections.reduce((sum, sec) => sum + sec.rows * sec.cols, 0),
  );

  const allSeats = [];
  sections.forEach((sec) => {
    for (let r = 0; r < sec.rows; r++) {
      for (let c = 0; c < sec.cols; c++) {
        allSeats.push({ sectionId: sec.id, localSeatId: seatId(r, c) });
      }
    }
  });

  const picked = shuffle(allSeats).slice(0, totalAvailable);
  const availableBySection = {};
  sections.forEach((sec) => {
    availableBySection[sec.id] = [];
  });
  picked.forEach(({ sectionId, localSeatId }) => {
    availableBySection[sectionId].push(localSeatId);
  });

  const result = {};
  sections.forEach((sec) => {
    result[sec.id] = buildSeatMapFromAvailability(
      sec.rows,
      sec.cols,
      availableBySection[sec.id],
    );
  });
  return result;
}

// ─── Section colour themes  (blue palette) ───────────────────────────
// Unavailable seats get NO colour — just a dim flat square.

function sectionStyle(sectionName = "") {
  const s = sectionName.toLowerCase();

  if (s.includes("vip")) {
    return {
      // available
      bg: "bg-violet-500/20 hover:bg-violet-500/35 border-violet-500/50 text-violet-200",
      // selected
      selected:
        "bg-violet-500 border-violet-400 text-white shadow-[0_0_6px_rgba(139,92,246,0.6)]",
      // taken — NO colour at all, just a dead grey box
      taken: "bg-[#1a1f2e] border-[#252d3d] opacity-40 cursor-not-allowed",
    };
  }

  if (s.includes("premium") || s.includes("gold")) {
    return {
      bg: "bg-sky-500/20 hover:bg-sky-500/35 border-sky-500/50 text-sky-200",
      selected:
        "bg-sky-500 border-sky-400 text-white shadow-[0_0_6px_rgba(14,165,233,0.6)]",
      taken: "bg-[#1a1f2e] border-[#252d3d] opacity-40 cursor-not-allowed",
    };
  }

  // Standard — blue tint
  return {
    bg: "bg-blue-500/15 hover:bg-blue-500/30 border-blue-500/40 text-blue-200",
    selected:
      "bg-blue-500 border-blue-400 text-white shadow-[0_0_6px_rgba(59,130,246,0.6)]",
    taken: "bg-[#1a1f2e] border-[#252d3d] opacity-40 cursor-not-allowed",
  };
}

// ─── Legend ───────────────────────────────────────────────────────────

function Legend({ showSection = false }) {
  return (
    <div className="flex items-center gap-4 flex-wrap mt-4 text-xs text-slate-400">
      <span className="flex items-center gap-1.5">
        <span className="inline-block w-4 h-4 rounded-[3px] bg-blue-500/20 border border-blue-500/50" />
        Available
      </span>
      <span className="flex items-center gap-1.5">
        <span className="inline-block w-4 h-4 rounded-[3px] bg-blue-500 border border-blue-400" />
        Selected
      </span>
      <span className="flex items-center gap-1.5">
        <span
          className="inline-block w-4 h-4 rounded-[3px] border opacity-40"
          style={{ background: "#1a1f2e", borderColor: "#252d3d" }}
        />
        Unavailable
      </span>
      {showSection && (
        <>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-4 h-4 rounded-[3px] bg-violet-500/20 border border-violet-500/50" />
            VIP
          </span>
          <span className="flex items-center gap-1.5">
            <span className="inline-block w-4 h-4 rounded-[3px] bg-sky-500/20 border border-sky-500/50" />
            Premium
          </span>
        </>
      )}
    </div>
  );
}

// ─── Summary / confirm bar ─────────────────────────────────────────────

function SummaryBar({ label, total, symbol, onConfirm, disabled }) {
  return (
    <div className="mt-5 flex items-center justify-between rounded-2xl bg-slate-950/80 border border-blue-900/40 px-5 py-4">
      <div>
        <p className="text-xs text-slate-400">Selection</p>
        <p className="text-sm font-semibold text-slate-100 mt-0.5">{label}</p>
      </div>
      <div className="flex items-center gap-4">
        {total > 0 && (
          <div className="text-right">
            <p className="text-[11px] text-slate-400">Total</p>
            <p className="text-sm font-semibold text-blue-300">
              {symbol}
              {total.toLocaleString()}
            </p>
          </div>
        )}
        <button
          type="button"
          onClick={onConfirm}
          disabled={disabled}
          className="inline-flex items-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-blue-600/25 disabled:cursor-not-allowed text-white font-semibold text-sm px-5 py-2.5 transition-all shadow-lg shadow-blue-900/40"
        >
          Continue
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────
// SHARED — Single seat button
// ─────────────────────────────────────────────────────────────────────

function SeatRow({
  rowIndex,
  cols,
  seatMap,
  selected,
  onToggle,
  section = "",
}) {
  const style = sectionStyle(section);

  return (
    <div className="flex items-center gap-[3px]">
      <span className="text-[10px] text-slate-600 w-4 text-right shrink-0 font-mono select-none">
        {rowLetter(rowIndex)}
      </span>
      {Array.from({ length: cols }).map((_, c) => {
        const id = seatId(rowIndex, c);
        const status = seatMap?.[rowIndex]?.[c] ?? "taken";
        const isTaken = status === "taken";
        const isSelected = selected.includes(id);

        let cls =
          "w-[20px] h-[18px] rounded-[3px] border text-[7px] font-mono flex items-center justify-center transition-all shrink-0 select-none";

        if (isTaken) {
          cls += ` ${style.taken}`;
        } else if (isSelected) {
          cls += ` ${style.selected} cursor-pointer`;
        } else {
          cls += ` ${style.bg} cursor-pointer text-transparent hover:text-current`;
        }

        return (
          <button
            key={id}
            type="button"
            title={isTaken ? "Unavailable" : id}
            disabled={isTaken}
            onClick={() => !isTaken && onToggle(id)}
            className={cls}
          >
            {c + 1}
          </button>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────
// LAYOUT 1 — STADIUM  (oval, field in centre)
// ─────────────────────────────────────────────────────────────────────

const STADIUM_SECTIONS = [
  {
    id: "north",
    prefix: "N",
    label: "North Stand",
    rows: 6,
    cols: 20,
    section: "Standard",
  },
  {
    id: "south",
    prefix: "S",
    label: "South Stand",
    rows: 6,
    cols: 20,
    section: "Premium",
  },
  {
    id: "east",
    prefix: "E",
    label: "East End",
    rows: 5,
    cols: 10,
    section: "Standard",
  },
  {
    id: "west",
    prefix: "W",
    label: "West End",
    rows: 5,
    cols: 10,
    section: "VIP",
  },
];

// Shared section-block wrapper style
const blockBase = {
  background: "rgba(15,23,42,0.6)",
  border: "1px solid rgba(59,130,246,0.12)",
};

function StadiumPicker({ event, selected, onToggle }) {
  const seatMaps = useMemo(
    () => buildSectionSeatMaps(STADIUM_SECTIONS, event?.seatingLayout ?? {}),
    [event],
  );

  return (
    <div className="w-full">
      <div
        className="relative mx-auto"
        style={{ width: "min(540px, 100%)", userSelect: "none" }}
      >
        {/* North */}
        <div className="mb-1">
          <p className="text-center text-[9px] text-blue-400/70 mb-1 uppercase tracking-widest font-semibold">
            North Stand · Standard
          </p>
          <div className="overflow-x-auto pb-1">
            <div
              className="mx-auto flex flex-col gap-[3px] items-center"
              style={{
                ...blockBase,
                borderTopLeftRadius: 64,
                borderTopRightRadius: 64,
                padding: "12px 10px 6px",
                width: "fit-content",
              }}
            >
              {Array.from({ length: STADIUM_SECTIONS[0].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={STADIUM_SECTIONS[0].cols}
                  seatMap={seatMaps.north}
                  selected={selected}
                  onToggle={(id) => onToggle(`N-${id}`)}
                  section="Standard"
                />
              ))}
            </div>
          </div>
        </div>

        {/* Middle row: West | Pitch | East */}
        <div className="flex gap-2 items-center justify-center">
          {/* West / VIP */}
          <div className="shrink-0">
            <p className="text-center text-[9px] text-violet-400/70 mb-1 uppercase tracking-widest font-semibold">
              W · VIP
            </p>
            <div
              className="flex flex-col gap-[3px] items-end p-2"
              style={{
                ...blockBase,
                border: "1px solid rgba(139,92,246,0.18)",
                borderTopLeftRadius: 44,
                borderBottomLeftRadius: 44,
              }}
            >
              {Array.from({ length: STADIUM_SECTIONS[3].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={STADIUM_SECTIONS[3].cols}
                  seatMap={seatMaps.west}
                  selected={selected}
                  onToggle={(id) => onToggle(`W-${id}`)}
                  section="VIP"
                />
              ))}
            </div>
          </div>

          {/* Pitch */}
          <div
            className="flex-1 flex items-center justify-center"
            style={{
              minWidth: 88,
              height: 88,
              borderRadius: "50%",
              background: "rgba(21,128,61,0.15)",
              border: "1px solid rgba(21,128,61,0.35)",
            }}
          >
            <span className="text-[9px] text-green-500/80 uppercase tracking-widest font-semibold">
              Pitch
            </span>
          </div>

          {/* East */}
          <div className="shrink-0">
            <p className="text-center text-[9px] text-blue-400/70 mb-1 uppercase tracking-widest font-semibold">
              E · Standard
            </p>
            <div
              className="flex flex-col gap-[3px] items-start p-2"
              style={{
                ...blockBase,
                borderTopRightRadius: 44,
                borderBottomRightRadius: 44,
              }}
            >
              {Array.from({ length: STADIUM_SECTIONS[2].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={STADIUM_SECTIONS[2].cols}
                  seatMap={seatMaps.east}
                  selected={selected}
                  onToggle={(id) => onToggle(`E-${id}`)}
                  section="Standard"
                />
              ))}
            </div>
          </div>
        </div>

        {/* South */}
        <div className="mt-1">
          <div className="overflow-x-auto pb-1">
            <div
              className="mx-auto flex flex-col-reverse gap-[3px] items-center"
              style={{
                ...blockBase,
                border: "1px solid rgba(14,165,233,0.18)",
                borderBottomLeftRadius: 64,
                borderBottomRightRadius: 64,
                padding: "6px 10px 12px",
                width: "fit-content",
              }}
            >
              {Array.from({ length: STADIUM_SECTIONS[1].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={STADIUM_SECTIONS[1].cols}
                  seatMap={seatMaps.south}
                  selected={selected}
                  onToggle={(id) => onToggle(`S-${id}`)}
                  section="Premium"
                />
              ))}
            </div>
          </div>
          <p className="text-center text-[9px] text-sky-400/70 mt-1 uppercase tracking-widest font-semibold">
            South Stand · Premium
          </p>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────
// LAYOUT 2 — CONCERT  (C-shape / horseshoe, stage at top)
// ─────────────────────────────────────────────────────────────────────

const CONCERT_SECTIONS = [
  { id: "left", label: "Left Block", rows: 8, cols: 10, section: "Standard" },
  {
    id: "centre",
    label: "Centre Block",
    rows: 10,
    cols: 16,
    section: "Premium",
  },
  { id: "right", label: "Right Block", rows: 8, cols: 10, section: "Standard" },
  {
    id: "left_bal",
    label: "Left Balcony",
    rows: 4,
    cols: 10,
    section: "Standard",
  },
  {
    id: "right_bal",
    label: "Right Balcony",
    rows: 4,
    cols: 10,
    section: "Standard",
  },
  {
    id: "floor",
    label: "Floor (GA)",
    rows: 0,
    cols: 0,
    section: "VIP",
    isGA: true,
    totalSpots: 80,
  },
];

function ConcertPicker({ event, selected, onToggle }) {
  const seatedSections = useMemo(
    () => CONCERT_SECTIONS.filter((s) => !s.isGA),
    [],
  );

  const seatMaps = useMemo(
    () => buildSectionSeatMaps(seatedSections, event?.seatingLayout ?? {}),
    [event, seatedSections],
  );

  const floorSelected = selected.filter((s) => s.startsWith("FLOOR-")).length;
  const floorTotalSpots =
    event?.seatingLayout?.floorAvailableSpots ??
    event?.seatingLayout?.gaAvailableSpots ??
    CONCERT_SECTIONS.find((s) => s.id === "floor")?.totalSpots ??
    80;

  const canAddFloorSpot = floorSelected < floorTotalSpots;

  return (
    <div className="w-full overflow-x-auto">
      <div
        className="mx-auto"
        style={{ minWidth: 320, maxWidth: 640, userSelect: "none" }}
      >
        {/* Stage */}
        <div className="flex items-center justify-center mb-4">
          <div
            className="px-10 py-2 text-xs text-blue-200/80 uppercase tracking-widest font-semibold rounded-lg"
            style={{
              background: "rgba(30,64,175,0.2)",
              border: "1px solid rgba(59,130,246,0.25)",
            }}
          >
            Stage
          </div>
        </div>

        {/* Floor GA */}
        <div className="flex justify-center mb-3">
          <button
            type="button"
            disabled={!canAddFloorSpot}
            onClick={() => {
              if (!canAddFloorSpot) return;
              const id = `FLOOR-${floorSelected + 1}`;
              onToggle(id);
            }}
            className="rounded-xl px-6 py-3 flex flex-col items-center gap-1 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            style={{
              background: "rgba(109,40,217,0.12)",
              border: "1px solid rgba(139,92,246,0.35)",
            }}
          >
            <span className="text-[10px] text-violet-300 uppercase tracking-widest font-semibold">
              Floor · VIP GA
            </span>
            <span className="text-xs text-violet-300/70">
              {floorSelected} / {floorTotalSpots} spots selected
            </span>
            <div className="flex gap-1 flex-wrap justify-center mt-1 max-w-[200px]">
              {Array.from({ length: Math.min(floorSelected, 20) }).map(
                (_, i) => (
                  <span
                    key={i}
                    className="inline-block w-2.5 h-2.5 rounded-full bg-violet-400"
                  />
                ),
              )}
              {Array.from({
                length: Math.min(
                  Math.max(floorTotalSpots - floorSelected, 0),
                  20,
                ),
              }).map((_, i) => (
                <span
                  key={`e-${i}`}
                  className="inline-block w-2.5 h-2.5 rounded-full"
                  style={{ background: "#1a1f2e", border: "1px solid #2d2a45" }}
                />
              ))}
            </div>
          </button>
        </div>

        {/* Main seating row */}
        <div className="flex gap-2 justify-center">
          {/* Left */}
          <div className="shrink-0">
            <p className="text-center text-[9px] text-blue-400/70 mb-1 uppercase tracking-widest font-semibold">
              Left
            </p>
            <div
              className="flex flex-col gap-[3px] p-2"
              style={{
                ...blockBase,
                borderTopLeftRadius: 40,
                borderBottomLeftRadius: 40,
              }}
            >
              {Array.from({ length: CONCERT_SECTIONS[0].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={CONCERT_SECTIONS[0].cols}
                  seatMap={seatMaps.left}
                  selected={selected}
                  onToggle={(id) => onToggle(`L-${id}`)}
                  section="Standard"
                />
              ))}
            </div>
          </div>

          {/* Centre / Premium */}
          <div className="shrink-0">
            <p className="text-center text-[9px] text-sky-400/70 mb-1 uppercase tracking-widest font-semibold">
              Centre · Premium
            </p>
            <div
              className="flex flex-col gap-[3px] p-2 rounded-lg"
              style={{
                background: "rgba(14,165,233,0.06)",
                border: "1px solid rgba(14,165,233,0.2)",
              }}
            >
              {Array.from({ length: CONCERT_SECTIONS[1].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={CONCERT_SECTIONS[1].cols}
                  seatMap={seatMaps.centre}
                  selected={selected}
                  onToggle={(id) => onToggle(`C-${id}`)}
                  section="Premium"
                />
              ))}
            </div>
          </div>

          {/* Right */}
          <div className="shrink-0">
            <p className="text-center text-[9px] text-blue-400/70 mb-1 uppercase tracking-widest font-semibold">
              Right
            </p>
            <div
              className="flex flex-col gap-[3px] p-2"
              style={{
                ...blockBase,
                borderTopRightRadius: 40,
                borderBottomRightRadius: 40,
              }}
            >
              {Array.from({ length: CONCERT_SECTIONS[2].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={CONCERT_SECTIONS[2].cols}
                  seatMap={seatMaps.right}
                  selected={selected}
                  onToggle={(id) => onToggle(`R-${id}`)}
                  section="Standard"
                />
              ))}
            </div>
          </div>
        </div>

        {/* Balcony row */}
        <div className="flex gap-2 justify-center mt-2">
          <div className="shrink-0">
            <p className="text-center text-[9px] text-blue-400/70 mb-1 uppercase tracking-widest font-semibold">
              Left Balcony
            </p>
            <div
              className="flex flex-col gap-[3px] p-2"
              style={{ ...blockBase, borderBottomLeftRadius: 40 }}
            >
              {Array.from({ length: CONCERT_SECTIONS[3].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={CONCERT_SECTIONS[3].cols}
                  seatMap={seatMaps.left_bal}
                  selected={selected}
                  onToggle={(id) => onToggle(`LB-${id}`)}
                  section="Standard"
                />
              ))}
            </div>
          </div>

          {/* Spacer to align balconies with outer stalls */}
          <div style={{ width: CONCERT_SECTIONS[1].cols * 23 + 16 }} />

          <div className="shrink-0">
            <p className="text-center text-[9px] text-blue-400/70 mb-1 uppercase tracking-widest font-semibold">
              Right Balcony
            </p>
            <div
              className="flex flex-col gap-[3px] p-2"
              style={{ ...blockBase, borderBottomRightRadius: 40 }}
            >
              {Array.from({ length: CONCERT_SECTIONS[4].rows }).map((_, r) => (
                <SeatRow
                  key={r}
                  rowIndex={r}
                  cols={CONCERT_SECTIONS[4].cols}
                  seatMap={seatMaps.right_bal}
                  selected={selected}
                  onToggle={(id) => onToggle(`RB-${id}`)}
                  section="Standard"
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────
// LAYOUT 3 — GENERAL ADMISSION  (ticket-type cards)
// ─────────────────────────────────────────────────────────────────────

function GAPicker({ event, gaSelections, onChangeGA }) {
  const types = event?.ticketTypes ?? [
    {
      id: "standard",
      label: "Standard",
      price: event?.price?.min ?? 30,
      available: event?.availableTickets ?? 10,
    },
    { id: "vip", label: "VIP", price: event?.price?.max ?? 80, available: 20 },
  ];

  const sym = currencySymbol(event?.price?.currency);

  return (
    <div className="flex flex-col gap-3">
      {types.map((t) => {
        const qty = gaSelections[t.id] ?? 0;
        const soldOut = t.available === 0;

        let cardStyle =
          "rounded-2xl border px-5 py-4 flex items-center justify-between gap-4 transition-all ";
        if (qty > 0) {
          cardStyle += "border-blue-500/50 bg-blue-500/10";
        } else if (soldOut) {
          cardStyle += "border-slate-800 bg-slate-900/30 opacity-40";
        } else {
          cardStyle +=
            "border-slate-800 bg-slate-900/50 hover:border-blue-800/60";
        }

        return (
          <div key={t.id} className={cardStyle}>
            <div>
              <p className="text-sm font-semibold text-slate-100">{t.label}</p>
              <p className="text-xs text-slate-400 mt-0.5">
                {sym}
                {t.price.toLocaleString()} per ticket
                {!soldOut && (
                  <span className="ml-2 text-blue-400">
                    · {t.available} left
                  </span>
                )}
                {soldOut && (
                  <span className="ml-2 text-slate-500">· Sold out</span>
                )}
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                disabled={qty === 0 || soldOut}
                onClick={() => onChangeGA(t.id, -1, t.available)}
                className="w-8 h-8 rounded-xl border border-slate-700 bg-slate-900 text-slate-200 text-lg flex items-center justify-center hover:border-blue-500/50 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              >
                −
              </button>
              <span className="w-5 text-center text-sm font-semibold text-slate-100">
                {qty}
              </span>
              <button
                type="button"
                disabled={qty >= t.available || soldOut}
                onClick={() => onChangeGA(t.id, +1, t.available)}
                className="w-8 h-8 rounded-xl border border-slate-700 bg-slate-900 text-slate-200 text-lg flex items-center justify-center hover:border-blue-500/50 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              >
                +
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────
// MAIN EXPORT
// ─────────────────────────────────────────────────────────────────────

export default function SeatPicker({ event, onConfirm }) {
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [gaSelections, setGaSelections] = useState({});

  const venueType = useMemo(() => {
    if (event?.venueType) return event.venueType;
    const cat = (event?.category ?? "").toLowerCase();
    if (
      cat.includes("sport") ||
      cat.includes("football") ||
      cat.includes("soccer") ||
      cat.includes("rugby") ||
      cat.includes("athletics") ||
      cat.includes("cricket")
    )
      return "stadium";
    if (
      cat.includes("concert") ||
      cat.includes("music") ||
      cat.includes("show") ||
      cat.includes("theatre") ||
      cat.includes("theater")
    )
      return "concert";
    return "ga";
  }, [event]);

  const hasSeats = venueType === "stadium" || venueType === "concert";
  const pricePerSeat = event?.price?.min ?? event?.price?.max ?? 0;
  const sym = currencySymbol(event?.price?.currency);

  const toggleSeat = useCallback((id) => {
    setSelectedSeats((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id],
    );
  }, []);

  const changeGA = useCallback((typeId, delta, max) => {
    setGaSelections((prev) => {
      const cur = prev[typeId] ?? 0;
      return { ...prev, [typeId]: Math.max(0, Math.min(max, cur + delta)) };
    });
  }, []);

  const seatsTotal = selectedSeats.length * pricePerSeat;

  const effectiveTypes = event?.ticketTypes ?? [
    {
      id: "standard",
      label: "Standard",
      price: event?.price?.min ?? 30,
      available: event?.availableTickets ?? 10,
    },
    { id: "vip", label: "VIP", price: event?.price?.max ?? 80, available: 20 },
  ];

  const gaTotal = effectiveTypes.reduce(
    (acc, t) => acc + (gaSelections[t.id] ?? 0) * t.price,
    0,
  );
  const gaTotalQty = Object.values(gaSelections).reduce((a, b) => a + b, 0);

  const seatedAvailableCount = useMemo(() => {
    if (!hasSeats) return 0;
    const sections =
      venueType === "stadium"
        ? STADIUM_SECTIONS
        : CONCERT_SECTIONS.filter((s) => !s.isGA);
    const maps = buildSectionSeatMaps(sections, event?.seatingLayout ?? {});
    return Object.values(maps).reduce(
      (sum, map) => sum + map.flat().filter((s) => s === "available").length,
      0,
    );
  }, [event, hasSeats, venueType]);

  const summaryLabel = hasSeats
    ? selectedSeats.length === 0
      ? "No seats selected"
      : `${selectedSeats.length} seat${selectedSeats.length > 1 ? "s" : ""} — ${selectedSeats.slice(0, 4).join(", ")}${selectedSeats.length > 4 ? "…" : ""}`
    : gaTotalQty === 0
      ? "No tickets selected"
      : `${gaTotalQty} ticket${gaTotalQty > 1 ? "s" : ""} selected`;

  const confirmDisabled = hasSeats
    ? selectedSeats.length === 0
    : gaTotalQty === 0;

  const handleConfirm = () => {
    if (hasSeats) {
      onConfirm?.({
        seats: selectedSeats,
        totalPrice: seatsTotal,
        currency: event?.price?.currency ?? "USD",
      });
    } else {
      onConfirm?.({
        tickets: effectiveTypes
          .filter((t) => (gaSelections[t.id] ?? 0) > 0)
          .map((t) => ({
            typeId: t.id,
            label: t.label,
            qty: gaSelections[t.id],
            price: t.price,
          })),
        totalPrice: gaTotal,
        currency: event?.price?.currency ?? "USD",
      });
    }
  };

  const venueLabel =
    venueType === "stadium"
      ? "Stadium layout"
      : venueType === "concert"
        ? "Concert / arena layout"
        : "General admission";

  return (
    <div
      className="rounded-3xl p-5 md:p-6 shadow-2xl shadow-black/50"
      style={{
        background: "rgba(8,14,32,0.85)",
        border: "1px solid rgba(59,130,246,0.18)",
        backdropFilter: "blur(12px)",
      }}
    >
      {/* Header */}
      <div className="mb-5 flex items-center justify-between flex-wrap gap-2">
        <div>
          <p className="text-[11px] uppercase tracking-[0.18em] text-blue-400/70 mb-0.5">
            Choose your seats
          </p>
          <p className="text-sm font-semibold text-slate-100">{venueLabel}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {hasSeats && (
            <div
              className="rounded-xl px-3 py-1.5 text-xs text-slate-300"
              style={{
                background: "rgba(15,23,42,0.7)",
                border: "1px solid rgba(59,130,246,0.2)",
              }}
            >
              {seatedAvailableCount} seat{seatedAvailableCount === 1 ? "" : "s"}{" "}
              available
            </div>
          )}
          {hasSeats && pricePerSeat > 0 && (
            <div
              className="rounded-xl px-3 py-1.5 text-xs text-slate-300"
              style={{
                background: "rgba(15,23,42,0.7)",
                border: "1px solid rgba(59,130,246,0.2)",
              }}
            >
              From{" "}
              <span className="text-blue-300 font-semibold">
                {sym}
                {pricePerSeat.toLocaleString()}
              </span>{" "}
              / seat
            </div>
          )}
        </div>
      </div>

      {/* Layout */}
      <div className="overflow-x-auto">
        {venueType === "stadium" && (
          <StadiumPicker
            event={event}
            selected={selectedSeats}
            onToggle={toggleSeat}
          />
        )}
        {venueType === "concert" && (
          <ConcertPicker
            event={event}
            selected={selectedSeats}
            onToggle={toggleSeat}
          />
        )}
        {venueType === "ga" && (
          <GAPicker
            event={event}
            gaSelections={gaSelections}
            onChangeGA={changeGA}
          />
        )}
      </div>

      {hasSeats && <Legend showSection />}

      <SummaryBar
        label={summaryLabel}
        total={hasSeats ? seatsTotal : gaTotal}
        symbol={sym}
        onConfirm={handleConfirm}
        disabled={confirmDisabled}
      />
    </div>
  );
}
