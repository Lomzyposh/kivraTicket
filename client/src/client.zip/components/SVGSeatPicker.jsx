/**
 * SVGSeatPicker.jsx
 * ─────────────────────────────────────────────────────────────────
 * Drop-in replacement for your current SeatPicker when venueType is
 * "svg-stadium" or "svg-concert".
 *
 * HOW TO ADD A NEW STADIUM SVG
 * ─────────────────────────────
 * 1. Copy your .svg file into src/assets/stadiums/
 * 2. Add an entry to STADIUM_CONFIGS below.
 * 3. On the event in MongoDB set:
 *      venueType: "svg-stadium"
 *      svgKey: "<your-config-key>"     ← must match the key you added
 *      price: { min: 50, max: 800, currency: "USD" }
 *    That's it. Pricing + colours are computed automatically.
 *
 * PRICING ALGORITHM
 * ─────────────────
 * Sections are grouped into TIERS. Each tier maps to a 0-1 "premium"
 * score (1 = most expensive). The final price per section is:
 *   price = min + score * (max - min)
 * Tiers are defined per-config and reflect real stadium geography:
 *   - Pitch-side / floor-level → highest score
 *   - Mid-tier sections        → mid score
 *   - Upper / nosebleed        → lowest score
 *   - Suites / VIP boxes       → highest (premium seating)
 *
 * PROPS
 * ─────
 * event      – full event object (needs price.min, price.max, svgKey)
 * onConfirm  – (payload) => void
 *              payload: { seats:[sectionId], totalPrice, sectionLabel,
 *                         category, qty, pricePerSeat }
 * onClose    – () => void   (back button)
 * ─────────────────────────────────────────────────────────────────
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { X, ChevronLeft, ChevronRight, Info, ZoomIn, ZoomOut } from "lucide-react";

// ─── Colour palette for each tier ────────────────────────────────
const TIER_COLORS = {
  platinum: { fill: "#e5c66e", stroke: "#c9a94e", label: "Platinum" },
  gold:     { fill: "#cd853f", stroke: "#a0622a", label: "Gold"     },
  silver:   { fill: "#4a90d9", stroke: "#2d6fa3", label: "Silver"   },
  bronze:   { fill: "#5dade2", stroke: "#3a8cc0", label: "Bronze"   },
  standard: { fill: "#82c86a", stroke: "#5aad42", label: "Standard" },
  economy:  { fill: "#8e9fa8", stroke: "#6b7c85", label: "Economy"  },
  vip:      { fill: "#9b59b6", stroke: "#7d3f98", label: "VIP Suite"},
  disabled: { fill: "#3a3a3a", stroke: "#222",    label: "Unavailable"},
};

const findSectionGroup = (container, sectionId) => {
  return (
    container.querySelector(`[id="${sectionId}-group"]`) ||
    container.querySelector(`[data-section-id="${sectionId}"]`)
  );
};

// ─── STADIUM CONFIGURATIONS ───────────────────────────────────────
// Add your SVGs here. Each section id from the SVG maps to a tier.
// Pattern-based matching: a string like "^10" matches sections starting with "10"
// Exact match:            just the section id itself, e.g. "vip"
// The tiers array is ordered platinum→economy for priority.
export const STADIUM_CONFIGS = {

  // ── Hard Rock Stadium (Match 13 Group H – Saudi Arabia vs Uruguay) ─
  "hard-rock": {
    name: "Hard Rock Stadium",
    // sections not listed fall to "standard"
    tiers: {
      vip:      ["vip", "suites", "loge-box", "127-vip", "119-vip"],
      platinum: ["101", "102", "103", "104", "105", "106", "111", "112",
                 "113", "114", "118", "119", "129"],
      gold:     ["107", "108", "109", "110", "115", "116", "117", "120",
                 "121", "122", "123", "124", "125", "126", "127", "128",
                 "130", "131"],
      silver:   ["201", "202", "203", "204", "205", "206", "207", "208",
                 "209", "210", "211", "212", "213", "214", "215", "216",
                 "217", "218"],
      bronze:   ["221", "222", "223", "224", "225", "226", "227", "228",
                 "229", "230", "231"],
      standard: ["228a", "203a", "212a", "213a", "214a", "215a", "216a",
                 "217a", "218a", "321a", "325a"],
      economy:  ["north-tables", "canada-standard", "canada-premium",
                 "canada-value"],
    },
    // Scores drive pricing: 1.0 = max price, 0.0 = min price
    tierScores: {
      vip: 1.0, platinum: 0.9, gold: 0.75, silver: 0.55,
      bronze: 0.35, standard: 0.2, economy: 0.1,
    },
    // How many "available" sections to randomly show (10–30 rule)
    availableCount: 22,
  },

  // ── Lusail Stadium (anotherStad.svg) ─────────────────────────────
  "lusail": {
    name: "Lusail Stadium",
    tiers: {
      vip:      ["vip", "pitchside-lounge", "fifa-pavilion", "trophy-lounge",
                 "champions-club"],
      platinum: ["101", "102", "103", "104", "105", "106", "107", "108",
                 "109", "110", "111", "118", "119", "120", "121", "122",
                 "123", "124", "125", "c-113", "c-114", "c-115", "c-116",
                 "c-117"],
      gold:     ["201", "202", "203", "204", "205", "206", "207", "208",
                 "209", "210", "211", "212", "213", "214", "215", "216",
                 "217", "218", "219", "220", "221", "222", "223", "224",
                 "225", "226", "227", "228", "229", "230", "231"],
      silver:   ["301", "302", "303", "304", "305", "306", "307", "308",
                 "309", "310", "311", "312", "313", "314", "315", "316",
                 "317", "318", "319", "320", "321", "322", "323", "324",
                 "325", "326", "327", "328"],
      bronze:   ["401", "402", "403", "404", "405", "406", "407", "408",
                 "409", "410", "411", "412", "413", "414", "415", "416",
                 "417", "418", "419", "420", "421", "422"],
      standard: ["c-135", "c-136", "c-137", "c-138", "c-139", "c-140",
                 "c-141", "c-212", "c-213", "c-214", "c-215", "c-216",
                 "c-217", "c-218", "c-219", "c-236", "c-237", "c-238",
                 "c-239", "c-240", "c-241", "c-242"],
      economy:  ["tier", "suites", "qatar-premium", "qatar-standard",
                 "qatar-value", "switzerland-premium", "switzerland-standard",
                 "switzerland-value", "126", "127", "128", "129", "130",
                 "131", "132", "133", "134", "142", "143", "144", "145",
                 "146", "232", "233", "234", "235", "243", "244", "245",
                 "246", "401-3", "401-4", "422-3", "422-4"],
    },
    tierScores: {
      vip: 1.0, platinum: 0.88, gold: 0.72, silver: 0.52,
      bronze: 0.32, standard: 0.18, economy: 0.08,
    },
    availableCount: 28,
  },
};

// ─── Utility helpers ──────────────────────────────────────────────

function getTierForSection(sectionId, config) {
  for (const [tier, ids] of Object.entries(config.tiers)) {
    if (ids.includes(sectionId)) return tier;
  }
  return "standard";
}

function getScoreForSection(sectionId, config) {
  const tier = getTierForSection(sectionId, config);
  return config.tierScores[tier] ?? 0.2;
}

function calcPrice(score, min, max) {
  return Math.round(min + score * (max - min));
}

function currencySymbol(code = "USD") {
  return { USD: "$", NGN: "₦", GBP: "£", EUR: "€" }[code] ?? "$";
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ─── Main Component ───────────────────────────────────────────────
export default function SVGSeatPicker({ event, onConfirm, onClose }) {
  const svgContainerRef = useRef(null);
  const svgRef = useRef(null);
  const [svgContent, setSvgContent] = useState(null);
  const [selectedSection, setSelectedSection] = useState(null);
  const [hoveredSection, setHoveredSection] = useState(null);
  const [qty, setQty] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [availableSections, setAvailableSections] = useState(new Set());
  const [sectionData, setSectionData] = useState({});
  const [svgLoaded, setSvgLoaded] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 1024);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const config = STADIUM_CONFIGS[event?.svgKey] ?? STADIUM_CONFIGS["hard-rock"];
  const priceMin = event?.price?.min ?? 50;
  const priceMax = event?.price?.max ?? 500;
  const currency = event?.price?.currency ?? "USD";
  const sym = currencySymbol(currency);

  // ── Load SVG content ──────────────────────────────────────────
  useEffect(() => {
    const key = event?.svgKey ?? "hard-rock";
    // In production you'd dynamically import the SVG.
    // We detect which SVG to use from the svgKey and load it.
    // The SVG files should be in public/stadiums/<key>.svg
    const svgPath = `/stadiums/${key}.svg`;

    fetch(svgPath)
      .then((r) => r.text())
      .then((text) => {
        setSvgContent(text);
        setSvgLoaded(true);
      })
      .catch(() => {
        // fallback: no SVG found, show error
        setSvgLoaded(false);
      });
  }, [event?.svgKey]);

  // ── Parse sections after SVG loads ───────────────────────────
  useEffect(() => {
    if (!svgLoaded || !svgRef.current) return;

    const container = svgRef.current;
    const allSections = container.querySelectorAll(".interactive-section");
    const ids = Array.from(allSections).map((el) => el.dataset.sectionId);

    // Remove non-interactive meta sections
    const skipIds = new Set(["cat1", "cat2", "cat3", "cat4", "cat-1", "cat-2",
      "cat-3", "cat-4", "cat1-group", "tier"]);

    const usableIds = ids.filter((id) => id && !skipIds.has(id));

    // Randomly pick availableCount sections
    const count = Math.min(config.availableCount, usableIds.length);
    const available = new Set(shuffle(usableIds).slice(0, count));
    setAvailableSections(available);

    // Build section data map
    const data = {};
    usableIds.forEach((id) => {
      const tier = getTierForSection(id, config);
      const score = getScoreForSection(id, config);
      const price = calcPrice(score, priceMin, priceMax);
      data[id] = {
        id,
        tier,
        score,
        price,
        label: id.toUpperCase().replace(/-/g, " "),
        available: available.has(id),
      };
    });
    setSectionData(data);

    // Colour the SVG sections
    usableIds.forEach((id) => {
      const el = findSectionGroup(container, id);
      if (!el) return;
      const pathEl = el.querySelector(".section-path, path");
      if (!pathEl) return;

      const isAvailable = available.has(id);
      const tier = getTierForSection(id, config);
      const colors = isAvailable ? TIER_COLORS[tier] : TIER_COLORS.disabled;
      pathEl.style.fill = colors.fill;
      pathEl.style.stroke = colors.stroke;
      pathEl.style.strokeWidth = "2";
      pathEl.style.cursor = isAvailable ? "pointer" : "not-allowed";
      pathEl.style.transition = "fill 0.15s, opacity 0.15s";
      pathEl.style.opacity = isAvailable ? "1" : "0.35";
    });
  }, [svgLoaded, config, priceMin, priceMax]);

  // ── Attach SVG click/hover handlers ──────────────────────────
  useEffect(() => {
    if (!svgRef.current || !svgLoaded) return;
    const container = svgRef.current;

    const handleClick = (e) => {
      const group = e.target.closest(".interactive-section");
      if (!group) return;
      const id = group.dataset.sectionId;
      if (!id || !availableSections.has(id)) return;
      setSelectedSection(id === selectedSection ? null : id);
    };

    const handleMouseOver = (e) => {
      const group = e.target.closest(".interactive-section");
      if (!group) return;
      const id = group.dataset.sectionId;
      if (!id || !availableSections.has(id)) return;
      setHoveredSection(id);
      const pathEl = group.querySelector(".section-path, path");
      if (pathEl) {
        pathEl.style.opacity = "0.8";
        pathEl.style.filter = "brightness(1.2)";
      }
    };

    const handleMouseOut = (e) => {
      const group = e.target.closest(".interactive-section");
      if (!group) return;
      const id = group.dataset.sectionId;
      if (!id) return;
      setHoveredSection(null);
      const pathEl = group.querySelector(".section-path, path");
      if (pathEl) {
        pathEl.style.opacity = availableSections.has(id) ? "1" : "0.35";
        pathEl.style.filter = "";
      }
    };

    container.addEventListener("click", handleClick);
    container.addEventListener("mouseover", handleMouseOver);
    container.addEventListener("mouseout", handleMouseOut);

    return () => {
      container.removeEventListener("click", handleClick);
      container.removeEventListener("mouseover", handleMouseOver);
      container.removeEventListener("mouseout", handleMouseOut);
    };
  }, [svgLoaded, availableSections, selectedSection]);

  // ── Highlight selected section ────────────────────────────────
  useEffect(() => {
    if (!svgRef.current || !svgLoaded) return;
    const container = svgRef.current;

    // Reset all first
    container.querySelectorAll(".interactive-section").forEach((group) => {
      const id = group.dataset.sectionId;
      if (!id || !availableSections.has(id)) return;
      const pathEl = group.querySelector(".section-path, path");
      if (!pathEl) return;
      const tier = getTierForSection(id, config);
      pathEl.style.stroke = TIER_COLORS[tier]?.stroke ?? "#555";
      pathEl.style.strokeWidth = "2";
      pathEl.style.filter = "";
    });

    // Highlight selected
    if (selectedSection) {
      const group = findSectionGroup(container, selectedSection);
      if (group) {
        const pathEl = group.querySelector(".section-path, path");
        if (pathEl) {
          pathEl.style.stroke = "#fff";
          pathEl.style.strokeWidth = "4";
          pathEl.style.filter = "drop-shadow(0 0 8px rgba(255,255,255,0.9))";
        }
      }
    }
  }, [selectedSection, svgLoaded, availableSections, config]);

  // ── Pan & Zoom handlers ───────────────────────────────────────
  const handleWheel = useCallback((e) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    setZoom((z) => Math.max(0.5, Math.min(3, z * delta)));
  }, []);

  const handleMouseDown = useCallback((e) => {
    if (e.button !== 0) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  }, [pan]);

  const handleMouseMove = useCallback((e) => {
    if (!isDragging) return;
    setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  }, [isDragging, dragStart]);

  const handleMouseUp = useCallback(() => setIsDragging(false), []);

  useEffect(() => {
    const el = svgContainerRef.current;
    if (!el) return;
    el.addEventListener("wheel", handleWheel, { passive: false });
    return () => el.removeEventListener("wheel", handleWheel);
  }, [handleWheel]);

  // ── Computed values ───────────────────────────────────────────
  const selected = selectedSection ? sectionData[selectedSection] : null;
  const totalPrice = selected ? selected.price * qty : 0;

  const tierLegend = useMemo(() => {
    const seen = new Set();
    const items = [];
    Object.values(sectionData).forEach(({ tier, price, available: av }) => {
      if (!av || seen.has(tier)) return;
      seen.add(tier);
      items.push({ tier, price, colors: TIER_COLORS[tier] });
    });
    return items.sort((a, b) => b.price - a.price);
  }, [sectionData]);

  const handleConfirm = () => {
    if (!selected) return;
    onConfirm({
      seats: [`${selected.label}-${Array.from({ length: qty }, (_, i) => i + 1).join(",")}`],
      sectionId: selected.id,
      sectionLabel: selected.label,
      category: TIER_COLORS[selected.tier]?.label ?? selected.tier,
      qty,
      pricePerSeat: selected.price,
      totalPrice,
    });
  };

  // ─── RENDER ──────────────────────────────────────────────────
  return (
    <div style={styles.overlay}>
      <div style={styles.panel}>

        {/* Header */}
        <div style={styles.header}>
          <button onClick={onClose} style={styles.backBtn}>
            <ChevronLeft size={18} /> Back
          </button>
          <div style={styles.headerTitle}>
            <span style={styles.venueName}>{config.name}</span>
            <span style={styles.availBadge}>
              {availableSections.size} sections available
            </span>
          </div>
          <div style={styles.zoomControls}>
            <button style={styles.zoomBtn} onClick={() => setZoom(z => Math.min(3, z * 1.2))}>
              <ZoomIn size={16} />
            </button>
            <button style={styles.zoomBtn} onClick={() => setZoom(z => Math.max(0.5, z / 1.2))}>
              <ZoomOut size={16} />
            </button>
            <button style={{ ...styles.zoomBtn, fontSize: 11 }}
              onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }}>
              Reset
            </button>
          </div>
        </div>

        <div style={{ ...styles.body, flexDirection: isMobile ? "column" : "row" }}>
          {/* SVG Container */}
          <div
            ref={svgContainerRef}
            style={{ ...styles.svgWrapper, cursor: isDragging ? "grabbing" : "grab", flex: isMobile ? "0 0 auto" : 1, height: isMobile ? "50vh" : "auto", minHeight: isMobile ? "50vh" : "auto" }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          >
            {!svgLoaded && (
              <div style={styles.svgFallback}>
                <div style={styles.spinnerRing} />
                <p style={{ color: "#aaa", marginTop: 12 }}>Loading stadium map…</p>
                <p style={{ color: "#666", fontSize: 12, marginTop: 6 }}>
                  Make sure /public/stadiums/{event?.svgKey ?? "hard-rock"}.svg exists
                </p>
              </div>
            )}
            <div
              ref={svgRef}
              style={{
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                transformOrigin: "center center",
                transition: isDragging ? "none" : "transform 0.1s",
                userSelect: "none",
              }}
              dangerouslySetInnerHTML={svgContent ? { __html: svgContent } : undefined}
            />
          </div>

          {/* Sidebar */}
          <div style={{ ...styles.sidebar, width: isMobile ? "100%" : 280, height: isMobile ? "auto" : "auto", maxHeight: isMobile ? "50vh" : "auto", borderLeft: isMobile ? "none" : styles.sidebar.borderLeft, borderTop: isMobile ? "1px solid rgba(59,130,246,0.15)" : "none" }}>
            {/* Legend */}
            <div style={styles.card}>
              <h3 style={styles.cardTitle}>Price Tiers</h3>
              <div style={styles.legendList}>
                {tierLegend.map(({ tier, price, colors }) => (
                  <div key={tier} style={styles.legendRow}>
                    <span style={{ ...styles.legendDot, background: colors.fill, border: `2px solid ${colors.stroke}` }} />
                    <span style={styles.legendLabel}>{colors.label}</span>
                    <span style={styles.legendPrice}>{sym}{price.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tooltip / Hovered */}
            {hoveredSection && sectionData[hoveredSection] && !selectedSection && (
              <div style={styles.card}>
                <div style={styles.hoverSection}>
                  <div style={{
                    ...styles.tierBadge,
                    background: TIER_COLORS[sectionData[hoveredSection].tier]?.fill,
                  }}>
                    {TIER_COLORS[sectionData[hoveredSection].tier]?.label}
                  </div>
                  <div style={styles.hoverName}>Section {sectionData[hoveredSection].label}</div>
                  <div style={styles.hoverPrice}>
                    {sym}{sectionData[hoveredSection].price.toLocaleString()}
                    <span style={{ fontSize: 12, color: "#aaa" }}> / seat</span>
                  </div>
                  <p style={{ fontSize: 12, color: "#777", marginTop: 4 }}>Click to select</p>
                </div>
              </div>
            )}

            {/* Selected section */}
            {selected && (
              <div style={{ ...styles.card, ...styles.selectedCard }}>
                <div style={styles.selectedHeader}>
                  <div style={{
                    ...styles.tierBadge,
                    background: TIER_COLORS[selected.tier]?.fill,
                    fontSize: 12,
                  }}>
                    {TIER_COLORS[selected.tier]?.label}
                  </div>
                  <button
                    style={styles.deselectBtn}
                    onClick={() => setSelectedSection(null)}
                  >
                    <X size={14} />
                  </button>
                </div>
                <div style={styles.selectedSection}>Section {selected.label}</div>
                <div style={styles.selectedPrice}>
                  {sym}{selected.price.toLocaleString()}
                  <span style={{ fontSize: 13, color: "#aaa" }}> / seat</span>
                </div>

                {/* Qty picker */}
                <div style={styles.qtyRow}>
                  <span style={styles.qtyLabel}>Quantity</span>
                  <div style={styles.qtyControls}>
                    <button style={styles.qtyBtn} onClick={() => setQty(q => Math.max(1, q - 1))}>−</button>
                    <span style={styles.qtyValue}>{qty}</span>
                    <button style={styles.qtyBtn} onClick={() => setQty(q => Math.min(10, q + 1))}>+</button>
                  </div>
                </div>

                <div style={styles.totalRow}>
                  <span style={{ color: "#aaa" }}>Total</span>
                  <span style={styles.totalPrice}>{sym}{totalPrice.toLocaleString()}</span>
                </div>

                <button style={styles.confirmBtn} onClick={handleConfirm}>
                  Continue to Checkout
                  <ChevronRight size={16} style={{ marginLeft: 4 }} />
                </button>
              </div>
            )}

            {/* Empty state */}
            {!selected && !hoveredSection && (
              <div style={styles.emptyHint}>
                <Info size={20} style={{ color: "#555", marginBottom: 8 }} />
                <p style={{ color: "#666", fontSize: 13, textAlign: "center" }}>
                  Click a highlighted section on the map to select your seats
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── STYLES ──────────────────────────────────────────────────────
const styles = {
  overlay: {
    position: "fixed", inset: 0, zIndex: 1000,
    background: "rgba(0,0,0,0.85)", backdropFilter: "blur(4px)",
    display: "flex", alignItems: "center", justifyContent: "center",
    padding: 16,
  },
  panel: {
    background: "rgb(15, 23, 42)", borderRadius: 16,
    border: "1px solid rgba(59,130,246,0.15)",
    width: "100%", maxWidth: 1100, height: "90vh",
    display: "flex", flexDirection: "column",
    overflow: "hidden",
    boxShadow: "0 24px 80px rgba(0,0,0,0.7)",
  },
  header: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    padding: "14px 20px",
    borderBottom: "1px solid rgba(59,130,246,0.15)",
    background: "rgb(8,14,32)",
    flexShrink: 0,
  },
  backBtn: {
    display: "flex", alignItems: "center", gap: 4,
    background: "none", border: "1px solid rgba(59,130,246,0.15)", borderRadius: 8,
    color: "rgb(148, 163, 184)", cursor: "pointer", padding: "6px 12px", fontSize: 13,
  },
  headerTitle: { display: "flex", flexDirection: "column", alignItems: "center" },
  venueName: { color: "rgb(248, 250, 252)", fontSize: 16, fontWeight: 700 },
  availBadge: {
    background: "rgba(59, 130, 246, 0.1)", color: "#3b82f6", fontSize: 11,
    padding: "2px 8px", borderRadius: 12, marginTop: 2,
  },
  zoomControls: { display: "flex", gap: 6 },
  zoomBtn: {
    background: "rgb(30, 41, 59)", border: "1px solid rgba(59,130,246,0.15)", borderRadius: 6,
    color: "rgb(148, 163, 184)", cursor: "pointer", padding: "5px 8px",
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  body: {
    display: "flex", flex: 1, overflow: "hidden",
  },
  svgWrapper: {
    flex: 1, overflow: "hidden", position: "relative",
    background: "rgb(8,14,32)",
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  svgFallback: {
    position: "absolute", display: "flex", flexDirection: "column",
    alignItems: "center", justifyContent: "center",
  },
  spinnerRing: {
    width: 36, height: 36, border: "3px solid rgb(71, 85, 105)",
    borderTop: "3px solid #3b82f6", borderRadius: "50%",
    animation: "spin 1s linear infinite",
  },
  sidebar: {
    width: 240, borderLeft: "1px solid rgba(59,130,246,0.15)",
    background: "linear-gradient(180deg, rgb(8,14,32) 0%, rgb(4,8,20) 100%)", padding: 16,
    overflowY: "auto", display: "flex", flexDirection: "column", gap: 14,
    flexShrink: 0,
  },
  card: {
    background: "linear-gradient(135deg, rgba(30,41,59,0.8) 0%, rgba(20,30,50,0.6) 100%)", borderRadius: 12,
    border: "1px solid rgba(59,130,246,0.2)", padding: 16,
    backdropFilter: "blur(8px)", boxShadow: "0 8px 32px rgba(0,0,0,0.3), inset 1px 1px 0 rgba(59,130,246,0.1)",
  },
  cardTitle: { color: "rgb(148, 163, 184)", fontSize: 12, textTransform: "uppercase",
    letterSpacing: 1.5, marginBottom: 12, fontWeight: 600 },
  legendList: { display: "flex", flexDirection: "column", gap: 9 },
  legendRow: { display: "flex", alignItems: "center", gap: 10, padding: "6px 8px", borderRadius: 6, transition: "background 0.2s", cursor: "pointer" },
  legendDot: { width: 14, height: 14, borderRadius: 4, flexShrink: 0, boxShadow: "0 2px 8px rgba(0,0,0,0.3)" },
  legendLabel: { flex: 1, color: "rgb(203, 213, 225)", fontSize: 13, fontWeight: 500 },
  legendPrice: { color: "rgb(100, 160, 220)", fontSize: 13, fontWeight: 600 },
  hoverSection: { textAlign: "center" },
  tierBadge: {
    display: "inline-block", padding: "3px 10px", borderRadius: 20,
    fontSize: 11, fontWeight: 700, color: "rgb(248, 250, 252)", marginBottom: 6,
  },
  hoverName: { color: "rgb(248, 250, 252)", fontSize: 16, fontWeight: 700 },
  hoverPrice: { color: "#3b82f6", fontSize: 22, fontWeight: 800, marginTop: 4 },
  selectedCard: { border: "1px solid rgba(59, 130, 246, 0.4)", background: "linear-gradient(135deg, rgba(30,41,59,1) 0%, rgba(20,30,50,0.8) 100%)", boxShadow: "0 8px 32px rgba(59,130,246,0.15), inset 1px 1px 0 rgba(59,130,246,0.2)" },
  selectedHeader: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    marginBottom: 8,
  },
  deselectBtn: {
    background: "rgb(51, 65, 85)", border: "none", borderRadius: 6,
    color: "rgb(148, 163, 184)", cursor: "pointer", padding: 4,
    display: "flex", alignItems: "center",
  },
  selectedSection: { color: "rgb(248, 250, 252)", fontSize: 17, fontWeight: 700 },
  selectedPrice: { color: "#3b82f6", fontSize: 24, fontWeight: 800, marginTop: 4 },
  qtyRow: {
    display: "flex", alignItems: "center", justifyContent: "space-between",
    marginTop: 14, marginBottom: 10,
  },
  qtyLabel: { color: "rgb(148, 163, 184)", fontSize: 13 },
  qtyControls: { display: "flex", alignItems: "center", gap: 10 },
  qtyBtn: {
    width: 28, height: 28, borderRadius: 6,
    background: "rgb(51, 65, 85)", border: "1px solid rgba(59,130,246,0.15)",
    color: "rgb(248, 250, 252)", fontSize: 18, cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center",
    lineHeight: 1,
  },
  qtyValue: { color: "rgb(248, 250, 252)", fontSize: 16, fontWeight: 700, minWidth: 20, textAlign: "center" },
  totalRow: {
    display: "flex", justifyContent: "space-between", alignItems: "center",
    borderTop: "1px solid rgba(59,130,246,0.15)", paddingTop: 10, marginBottom: 14,
  },
  totalPrice: { color: "rgb(248, 250, 252)", fontSize: 18, fontWeight: 800 },
  confirmBtn: {
    width: "100%", background: "linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)", color: "rgb(248, 250, 252)",
    border: "1px solid rgba(59,130,246,0.5)", borderRadius: 10, padding: "12px 0",
    fontWeight: 700, fontSize: 15, cursor: "pointer",
    display: "flex", alignItems: "center", justifyContent: "center",
    transition: "all 0.2s", boxShadow: "0 8px 16px rgba(59,130,246,0.3)",
  },
  emptyHint: {
    display: "flex", flexDirection: "column",
    alignItems: "center", padding: "20px 10px",
  },
};
