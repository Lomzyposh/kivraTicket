/**
 * stadiumConfigs.js
 * ─────────────────────────────────────────────────────────────────
 * Central config for all SVG-based stadium seat pickers.
 *
 * ═══════════════════════════════════════════════════════════════
 * HOW TO ADD A NEW STADIUM IN 3 STEPS
 * ═══════════════════════════════════════════════════════════════
 *
 * STEP 1 — Save your .svg file
 *   Put the file in:  public/stadiums/<your-key>.svg
 *   Example:          public/stadiums/sofi-stadium.svg
 *
 * STEP 2 — Add a config entry below
 *   Copy the template at the bottom and fill in:
 *     a) The section IDs from your SVG (look for data-section-id="...")
 *     b) Which sections are most expensive (pitch-side = platinum)
 *     c) How many sections to show as available (10–30)
 *
 * STEP 3 — Set the event in MongoDB
 *   {
 *     venueType: "svg-stadium",
 *     svgKey: "your-key",          ← must match key in this file
 *     price: { min: 80, max: 600, currency: "USD" }
 *   }
 *
 * ═══════════════════════════════════════════════════════════════
 * PRICING ALGORITHM
 * ═══════════════════════════════════════════════════════════════
 *
 * Each tier has a "score" from 0 (cheapest) to 1 (most expensive).
 * Final price = min + score × (max − min)
 *
 * GEOGRAPHICAL RULE OF THUMB:
 *   Platinum / Gold  → pitch-side, lower bowl, sideline sections
 *   Silver / Bronze  → mid-tier, end-zone, upper sections near centre
 *   Standard         → upper bowl, corners
 *   Economy          → nosebleed, restricted-view, supporter ends
 *   VIP              → suites, skyboxes, hospitality lounges → highest
 *
 * ═══════════════════════════════════════════════════════════════
 */

export const TIER_COLORS = {
  vip:      { fill: "#9b59b6", stroke: "#7d3f98", label: "VIP Suite",  textColor: "#fff" },
  platinum: { fill: "#e5c66e", stroke: "#c9a94e", label: "Platinum",   textColor: "#000" },
  gold:     { fill: "#cd853f", stroke: "#a0622a", label: "Gold",       textColor: "#fff" },
  silver:   { fill: "#4a90d9", stroke: "#2d6fa3", label: "Silver",     textColor: "#fff" },
  bronze:   { fill: "#5dade2", stroke: "#3a8cc0", label: "Bronze",     textColor: "#000" },
  standard: { fill: "#82c86a", stroke: "#5aad42", label: "Standard",   textColor: "#000" },
  economy:  { fill: "#8e9fa8", stroke: "#6b7c85", label: "Economy",    textColor: "#fff" },
  disabled: { fill: "#2a2a2a", stroke: "#1a1a1a", label: "Unavailable",textColor: "#555" },
};

export const STADIUM_CONFIGS = {

  // ── Hard Rock Stadium (Miami) ─────────────────────────────────
  // Used for FIFA World Cup 2026 matches
  "hard-rock": {
    name: "Hard Rock Stadium",
    city: "Miami Gardens, FL",
    svgFile: "hard-rock.svg",   // copy svj.svg → public/stadiums/hard-rock.svg
    availableCount: 22,         // 10–30 available sections shown randomly

    tiers: {
      vip:      [
        "vip", "suites", "loge-box", "127-vip", "119-vip",
      ],
      platinum: [
        "101", "102", "103", "104", "105", "106",
        "111", "112", "113", "114",
        "118", "119", "129",
      ],
      gold: [
        "107", "108", "109", "110",
        "115", "116", "117",
        "120", "121", "122", "123", "124", "125",
        "126", "127", "128", "130", "131",
      ],
      silver: [
        "201", "202", "203", "204", "205", "206", "207", "208",
        "209", "210", "211", "212", "213", "214", "215", "216",
        "217", "218",
      ],
      bronze: [
        "221", "222", "223", "224", "225", "226", "227", "228",
        "229", "230", "231",
      ],
      standard: [
        "228a", "203a", "212a", "213a", "214a", "215a", "216a",
        "217a", "218a", "321a", "325a",
        "208a", "206a", "109a", "110a", "105a", "106a",
        "115a", "124a",
        "132f", "131f", "133f",
      ],
      economy: [
        "north-tables", "canada-standard", "canada-premium", "canada-value",
      ],
    },

    tierScores: {
      vip: 1.0, platinum: 0.90, gold: 0.75,
      silver: 0.55, bronze: 0.35, standard: 0.20, economy: 0.10,
    },
  },

  // ── Lusail Iconic Stadium (Qatar) ─────────────────────────────
  // Used for FIFA 2026 matches at this venue
  "lusail": {
    name: "Lusail Iconic Stadium",
    city: "Lusail, Qatar",
    svgFile: "lusail.svg",      // copy anotherStad.svg → public/stadiums/lusail.svg
    availableCount: 28,

    tiers: {
      vip: [
        "vip", "pitchside-lounge", "fifa-pavilion",
        "trophy-lounge", "champions-club",
      ],
      platinum: [
        "101", "102", "103", "104", "105", "106", "107", "108",
        "109", "110", "111", "118", "119", "120", "121", "122",
        "123", "124", "125",
        "c-113", "c-114", "c-115", "c-116", "c-117",
      ],
      gold: [
        "201", "202", "203", "204", "205", "206", "207", "208",
        "209", "210", "211", "212", "213", "214", "215", "216",
        "217", "218", "219", "220", "221", "222", "223", "224",
        "225", "226", "227", "228", "229", "230", "231",
      ],
      silver: [
        "301", "302", "303", "304", "305", "306", "307", "308",
        "309", "310", "311", "312", "313", "314", "315", "316",
        "317", "318", "319", "320", "321", "322", "323", "324",
        "325", "326", "327", "328",
      ],
      bronze: [
        "401", "402", "403", "404", "405", "406", "407", "408",
        "409", "410", "411", "412", "413", "414", "415", "416",
        "417", "418", "419", "420", "421", "422",
        "401-3", "401-4", "422-3", "422-4",
      ],
      standard: [
        "c-135", "c-136", "c-137", "c-138", "c-139", "c-140", "c-141",
        "c212", "c213", "c-214", "c215", "c-216", "c217", "c218", "c219",
        "c-236", "c-237", "c-238", "c-239", "c-240", "c-241", "c-242",
        "126", "127", "128", "129", "130", "131", "132", "133", "134",
        "142", "143", "144", "145", "146",
        "232", "233", "234", "235",
        "243", "244", "245", "246",
        "210", "211", "220", "221", "222",
      ],
      economy: [
        "tier", "suites",
        "qatar-premium", "qatar-standard", "qatar-value",
        "switzerland-premium", "switzerland-standard", "switzerland-value",
      ],
    },

    tierScores: {
      vip: 1.0, platinum: 0.88, gold: 0.72,
      silver: 0.52, bronze: 0.32, standard: 0.18, economy: 0.08,
    },
  },

  // ════════════════════════════════════════════════════════════════
  // TEMPLATE — copy this block and fill in for each new stadium
  // ════════════════════════════════════════════════════════════════
  /*
  "your-stadium-key": {
    name: "Stadium Display Name",
    city: "City, State",
    svgFile: "your-stadium-key.svg",   // file in public/stadiums/
    availableCount: 20,                // between 10 and 30

    tiers: {
      vip:      ["section-id-1", "section-id-2"],   // suites, skyboxes
      platinum: ["section-id-3", "section-id-4"],   // pitch-side, floor
      gold:     ["section-id-5"],                    // lower bowl sideline
      silver:   ["section-id-6"],                    // mid-tier centre
      bronze:   ["section-id-7"],                    // upper bowl centre
      standard: ["section-id-8"],                    // corners, upper bowl
      economy:  ["section-id-9"],                    // end zones, supporter
    },

    tierScores: {
      vip: 1.0, platinum: 0.90, gold: 0.75,
      silver: 0.55, bronze: 0.35, standard: 0.20, economy: 0.10,
    },
  },
  */
};

// ── Helper: get tier for a section ID ────────────────────────────
export function getTierForSection(sectionId, config) {
  for (const [tier, ids] of Object.entries(config.tiers)) {
    if (ids.includes(sectionId)) return tier;
  }
  return "standard";
}

// ── Helper: compute price for a section ──────────────────────────
export function getSectionPrice(sectionId, config, priceMin, priceMax) {
  const tier = getTierForSection(sectionId, config);
  const score = config.tierScores[tier] ?? 0.2;
  return Math.round(priceMin + score * (priceMax - priceMin));
}
